#!/usr/bin/env python3

import json
import os
import glob
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# Define the report directory
report_dir = "/tmp/compliance_report"

# Gather all .json files
data_files = glob.glob(os.path.join(report_dir, "*.json"))

if not data_files:
    print("No JSON data files found in", report_dir)
    exit(1)

# Load data from all files
rows = []
for filepath in data_files:
    with open(filepath) as f:
        try:
            rows.append(json.load(f))
        except Exception as e:
            print(f"Error reading {filepath}: {e}")

# Convert to DataFrame with the new schedule column
df = pd.DataFrame(rows)

# Reorder columns (now includes schedule)
columns = ["ip", "name", "os", "kernel", "uptime", "compliance", "schedule"]
df = df[[col for col in columns if col in df.columns]]

# Output Excel file path
excel_file = os.path.join(report_dir, "compliance_report.xlsx")

# Write to Excel with enhanced styling
with pd.ExcelWriter(excel_file, engine="openpyxl") as writer:
    df.to_excel(writer, sheet_name="Compliance Report", index=False)
    worksheet = writer.sheets["Compliance Report"]

    # Set column widths
    col_widths = {
        "ip": 15,
        "name": 25,
        "os": 20,
        "kernel": 20,
        "uptime": 15,
        "compliance": 15,
        "schedule": 20
    }
    
    for i, column in enumerate(df.columns, 1):
        worksheet.column_dimensions[get_column_letter(i)].width = col_widths.get(column, 15)

    # Style header row
    header_fill = PatternFill(start_color="0070C0", end_color="0070C0", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    
    for cell in worksheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    # Apply conditional formatting
    for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row):
        for cell in row:
            # Center align all cells
            cell.alignment = Alignment(horizontal="center")
            
            # Compliance status coloring
            if cell.column == 6:  # Compliance column
                if "compliant" in str(cell.value).lower():
                    cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                elif "non-compliant" in str(cell.value).lower() or "unknown" in str(cell.value).lower():
                    cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
            
            # Schedule status coloring
            if cell.column == 7:  # Schedule column
                if "scheduled" in str(cell.value).lower():
                    cell.fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")

print(f"✅ Excel report generated: {excel_file}")
